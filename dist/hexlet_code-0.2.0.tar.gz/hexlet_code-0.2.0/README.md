### Hexlet tests and linter status:
[![Actions Status](https://github.com/baklazhanUA/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/baklazhanUA/python-project-49/actions)


<a href="https://codeclimate.com/github/baklazhanUA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5f6135fd2cff638650d1/maintainability" /></a>

https://asciinema.org/a/PxWJqhbGv5fHO2l3AbHKeYFAG
