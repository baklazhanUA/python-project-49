### Hexlet tests and linter status:
[![Actions Status](https://github.com/baklazhanUA/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/baklazhanUA/python-project-49/actions)


<a href="https://codeclimate.com/github/baklazhanUA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5f6135fd2cff638650d1/maintainability" /></a>

brain-even https://asciinema.org/a/PxWJqhbGv5fHO2l3AbHKeYFAG

brain-calc https://asciinema.org/a/oUW8zyMMvXcUbsry00IOwQDPY

brain-gcd https://asciinema.org/a/VVRxKJeQwac441AJY4a63ekEi

brain-progression https://asciinema.org/a/UR7DSH9bxbYwscjbFknXyps4y